# Advanced Quiz Exam Bot (Render Ready)

এই project টি Render web service এ deploy করার জন্য ready করে বানানো হয়েছে। Bot টি lightweight SQLite storage ব্যবহার করে, leaderboard image তৈরি করে, 10+ participant হলে PDF report পাঠায়, admin panel দেয়, schedule support করে, এবং exam চলাকালে non-admin message auto-delete mode চালু রাখে।

## Main Features
- Button-based PM admin panel
- `/` এবং `.` — দুই prefix এ command support
- Quiz poll forward করে question import
- CSV upload করে bulk question import
- Multi-group support
- Channel join gate for DM access/result eligibility
- Countdown + pin + pin service message cleanup
- Per-question timed quiz flow
- Leaderboard image generation
- 10+ participants হলে সুন্দর PDF report owner/admin inbox এ
- Per-user DM result with correct/wrong/skipped + question links
- Owner audit/logs/broadcast/announce
- Scheduled exam start
- Exam চলাকালে non-admin group messages auto-delete
- Auto-cleanup of old sessions/state
- Rotating logs to stay storage-light

## Important Telegram Notes
- Reliable join-check এর জন্য required channel এ bot-কে add/admin করা ভালো।
- কিছু forwarded quiz poll এ Telegram `correct_option_id` দেয় না। সেই case এ CSV import ব্যবহার করুন।
- Telegram group message selectively “hide” করা যায় না। তাই non-member answer ignore করা হয়েছে, DM access/result gate করা হয়েছে, আর exam চলাকালে non-admin extra message delete করা হয়েছে।

## Files
- `main.py` — main bot file
- `requirements.txt` — Python packages
- `render.yaml` — Render Blueprint
- `.env.example` — required environment values
- `COMMANDS.md` — full command list
- `sample_questions.csv` — import sample

## Render Deploy
1. এই folder GitHub repository তে upload করুন
2. Render এ **New + → Blueprint** বা **New Web Service** দিন
3. repo connect করুন
4. `render.yaml` use করুন
5. environment এ `BOT_TOKEN` এবং `OWNER_IDS` set করুন
6. deploy complete হলে bot run করবে

## Required Environment Variables
- `BOT_TOKEN` — Telegram bot token
- `OWNER_IDS` — comma-separated Telegram user ids

## Optional Environment Variables
- `REQUIRED_CHANNEL` — default `@FX_Ur_Target`
- `BOT_BRAND` — leaderboard/report branding text
- `TZ` — default `Asia/Dhaka`
- `RESULT_RETENTION_HOURS` — session cleanup window
- `SCOREBOARD_TOP_N` — leaderboard top count
- `COUNTDOWN_SECONDS` — exam countdown seconds
- `AUTO_DELETE_CONTROL_AFTER` — reserved cleanup window
- `LOG_LEVEL` — `INFO`, `WARNING`, `ERROR`
- `PYTHON_VERSION` — Render env var, already included in `render.yaml`

## CSV Format
Minimum:
```csv
questions,option1,option2,answer
```

Recommended:
```csv
questions,option1,option2,option3,option4,answer,explanation,type,section
```

`answer` field এ option number (1/2/3/4) অথবা exact option text দিতে পারবেন।

## Setup Checklist
- BotFather থেকে bot token নিন
- bot-কে target group এ add করুন
- group এ bot-কে required admin permissions দিন:
  - Delete messages
  - Pin messages
  - Poll management related permissions (Telegram client wording অনুযায়ী)
- required channel থাকলে সেখানে bot-কে add/admin দিন
- owner/admin user রা আগে PM এ `/start` দিন

## Quick Use
1. PM এ `/newexam`
2. Title দিন
3. Per-question time দিন
4. Negative mark দিন
5. Quiz poll forward করুন বা CSV upload করুন
6. Target group এ `/binddraft CODE`
7. `/starttqex` বা `/schedule YYYY-MM-DD HH:MM`

## Honest Limits
এই build টি syntax-checked করা হয়েছে, কিন্তু real Telegram token/group/channel permission ছাড়া end-to-end live test এই environment এ করা যায়নি। Deploy এর পর প্রথমবার test group এ dry run করে নিলেই best হবে।
